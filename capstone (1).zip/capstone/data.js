
var EmployeeId = localStorage.getItem("txtEmpId");
var name= EmployeeId.replace(/@.*/, "").replace(".", ' ').split(' ').slice(-1).join(' ');
document.getElementById("username").innerHTML = `Welcome ${name}`;

// for date
var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
var today  = new Date();
document.getElementById('printDate').innerHTML = today.toLocaleDateString("en-US", options);

var releaseDate={};
  const sendHttpRequest = () => {
    const proxyURL = "https://cors-anywhere.herokuapp.com";
    const url = "https://api.appfigures.com/v2/reports/sales/?group_by=products&client_key=2ee6914b8b7e42f5b4d3fcabde7e7a48/";
  
    const xhr = new XMLHttpRequest();

    xhr.responseType = 'json';
    var tableDataArray = []
    
    xhr.onload = () => {
        console.log(xhr.response);
        var results = Object.values(xhr.response);
        for (i in results){
          var releasedDate = results[i].product.release_date.substring(0, 10);
          releaseDate[results[i].product.name]=releasedDate
        }
        localStorage.setItem("releaseDate",JSON.stringify(releaseDate));
         //maping it to an Array form
         var resultsAsArray = results.map(function(obj) {
             return Object.keys(obj).sort().map(function(key) { 
               return obj[key];
             });
           });
          console.log("resultsAsArray is **************");
          console.log(resultsAsArray[0][13]);

         
         for (var i=0; i<5; i++){
             var temp = []
             temp.push(i+1)
             temp.push(resultsAsArray[i][13].name)
             temp.push(results[i].downloads)
             temp.push(results[i].revenue)
             temp.push(results[i].updates)
             temp.push(results[i].uninstalls)
          
           tableDataArray.push(temp);
         }

           console.log(tableDataArray)
         
 
         $(document).ready(function() {
             $('#myTable').DataTable( {
                 data: tableDataArray,
                 columns: [
                    { title: "#"},
                    { title: "App Name"},
                    { title: "Downloads" },
                    { title: "Revenue" },
                    { title: "Updates" },
                    { title: "Uninstalls" }
             ],
             searching: true
             } );
             // for href link another page hyperlink function
             for (var i=0; i<tableDataArray.length; i++) {
              var url = 'representation.html';
              document.getElementById('myTable').rows[i+1].cells[1].innerHTML = '<a href="' + url +'?appName='+tableDataArray[i][1]+ '">' + tableDataArray[i][1] + '</a>'; 
            }
             for (var i=0; i<tableDataArray.length; i++) {
              var imageSource = (resultsAsArray[i][13].icon)
              var appIcon = document.createElement("img")
              appIcon.src = imageSource
              console.log("image source is: " + imageSource)
              var table = document.getElementById('myTable')
              tableIconCell = table.rows[i+1].cells[1]
              tableIconCell.appendChild(appIcon)
              appIcon.style.width = '25px';
              appIcon.style.float = 'left';
            }
         } );
 
   }
    xhr.open('GET', proxyURL + "/" + url, true);
  

  xhr.setRequestHeader("X-Client-Key", "2ee6914b8b7e42f5b4d3fcabde7e7a48");
  xhr.setRequestHeader("Authorization", "Basic bmFnZWViLmRhbWFuaUBzb3plbnRlY2guY29tOkBwcEZpZ3VyZXMxMjM=");
  xhr.send();
}


 
