
const auth = firebase.auth();

/*Get HTML Objects*/
const btnFrgtPwd = document.getElementById("forgetPasswordbtn");
const email = document.getElementById("email");

  btnFrgtPwd.addEventListener("click", () =>{
    var email = document.getElementById("email").value;
   var actionCodeSettings = {
    // After password reset, the user will be give the ability to go back
    // to this page.
    url: 'https://sozentech.com/',
    handleCodeInApp: false
  };
    if(email !=""){
                auth.sendPasswordResetEmail(email, actionCodeSettings)
                .then(function() {
                  // Password reset email sent.
                  alert("Password reset instructions have been sent to your email.");
                  document.getElementById("email").value=" ";
                  })
              .catch(function(e){
                if(e.code=="auth/user-not-found"){
                  alert("You are not authorized, please contact your manager.");
                  document.getElementById("email").value="  ";
              }
              else if(e.code=="auth/invalid-email"){
                  alert("Please enter a valid email address.");
                  document.getElementById("email").value=" ";
              }
              else{
                 console.log(e);
              }
              });
            }
            else{
              window.alert("Please enter your email.");
            }
  });


    email.addEventListener("keyup",function(event){
        if(event.keyCode==13){
            event.preventDefault();
            btnFrgtPwd.click();
        }
    })

