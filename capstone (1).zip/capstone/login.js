
  const auth = firebase.auth();
  
  /*Get HTML Objects*/
  const txtEmpId = document.getElementById("empID");
  localStorage.setItem("txtEmpId", 'txtEmpId');
  const txtpsw = document.getElementById("password");
  const btnLogin = document.getElementById("login");

  /*On Login Click*/

  btnLogin.addEventListener("click", e=> {
    const empId = txtEmpId.value;
    localStorage.setItem("txtEmpId", empId);
    const pwd = txtpsw.value;
    const promise = auth.signInWithEmailAndPassword(empId,pwd);
    promise.catch(e => {
         if(e.code=="auth/user-not-found"){
             alert("You are not authorized, please contact your manager.");
             txtEmpId.value="";
             txtpsw.value="";
         }
         else if(e.code=="auth/invalid-email"){
             alert("Please enter a valid email address.");
             txtEmpId.value="";
             txtpsw.value="";
         }
         else if(e.code=="auth/wrong-password"){
             alert("Invalid password, please try again.");
             txtpsw.value="";
         }
         else{
            console.log(e);
         }
    });
    
  });

  //On hitting enter on password textbox
  txtpsw.addEventListener("keyup",function(event){
      if(event.keyCode==13){
          event.preventDefault();
          btnLogin.click();
      }
  })

  auth.onAuthStateChanged(firebaseUser => {
    if(firebaseUser){
        window.open("./Data Name page .html","_self")
    }
    else{
        // If user is not logged in
    }
});
