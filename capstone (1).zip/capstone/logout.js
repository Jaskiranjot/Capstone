
  const auth = firebase.auth();
  document.getElementById("logout").addEventListener("click",e=>{
    auth.signOut().then(function() {
        window.open("./Login.html","_self")
      }).catch(function(error) {
            console.log(error.Message);
      });      
  });
  auth.onAuthStateChanged(firebaseUser => {
    if(firebaseUser){
        
    }
    else{
        window.open("./Login.html","_self")
    }
});


