async function selectFunction(products) {
  var start_date = document.getElementById("from_date").value;
  //console.log(start_date)
  var end_date = document.getElementById("to_date").value;
  //console.log(end_date)
  
  var countries = document.getElementById("countryselected").value;
  //console.log(countries)

  //var products=document.getElementById("clientname_p").value;
  //console.log(products)
  var product_id = getProductId(products);

  // API call to get chart data
  const x_dates=[];
  const y_downloads=[];
  const y_revenue = [];
  const y_updates = [];
  
  function sendHttpRequest4(){
      return new Promise((resolve, reject) => {
      var xhr = new XMLHttpRequest();
      const proxyURL = "https://cors-anywhere.herokuapp.com";
      const url = `https://api.appfigures.com/v2/reports/sales/?group_by=dates&start=${start_date}&end_date=${end_date}&granularity=monthly&products=${product_id}&countries=${countries}`;
      xhr.open("GET", proxyURL + "/" + url, true);
      xhr.setRequestHeader("X-Client-Key", "2ee6914b8b7e42f5b4d3fcabde7e7a48");
      xhr.setRequestHeader("Authorization", "Basic bmFnZWViLmRhbWFuaUBzb3plbnRlY2guY29tOkBwcEZpZ3VyZXMxMjM=");
      xhr.responseType = 'json';
      xhr.onload = () => {
        var results = Object.values(xhr.response);
        console.log("*******chart 1 API results***************")
        console.log(results);
        //alert("got api results");
        for(i in results) {

          //Set X Axis (Months)
          var date=results[i].date;
          /*Get Month*/
          var dateParts = date.split("-");
          var dt = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
          const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          x_dates.push(monthNames[dt.getMonth()]);

          //Set Downloads
          var downloads=results[i].downloads
          y_downloads.push(parseFloat(downloads))

          //Set Revenue
          var rev = results[i].revenue;
          y_revenue.push(rev);

          //Set Updates
          var updates=results[i].updates;
          y_updates.push(parseFloat(updates));
      }
      resolve(x_dates,y_downloads,y_revenue,y_updates);
      }  
      xhr.send();  
    });
  }

  chartIt(); 
  async function chartIt() {  

    //Get data
    await sendHttpRequest4();

    //global options
    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';
    /* Start axes from 0*/
    Chart.scaleService.updateScaleDefaults('linear', {
      ticks: {
          min: 0
      }
    });

    // Chart 1 : Number of Downloads
    document.getElementById("chartContainer1").innerHTML = '&nbsp;';
    document.getElementById("chartContainer1").innerHTML = '<canvas id="myChart"></canvas>';
    var ctx = document.getElementById('myChart').getContext('2d');
    
    const mychart = new Chart(ctx, {
      type: 'bar',
      data:{
        labels: x_dates,
        datasets:[{
            label:"Downloads",
            data:y_downloads,
            backgroundColor: 'blue',
            borderWidth:1,
            borderColor:'black',
            hoverBorderWidth:2,
          }]
      },
      options: {
        title:{
          display:true,
          text:'Number of Downloads',
          fontSize:25
        },
        legend:{
          display:false,
          position:'right',
          labels:{
              fontColor:'orange'
          },
          onClick: (e) => e.stopPropagation()
        },
        layout:{
          padding:{
            left:20,
            right:20,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true
        },
        responsive: true,
      }
    });
    
    //Chart 2: Sales/Revenue
    document.getElementById("chartContainer2").innerHTML = '&nbsp;';
    document.getElementById("chartContainer2").innerHTML = '<canvas id="barChart">barchart</canvas>';
    var ctx2 = document.getElementById('barChart').getContext('2d');
    const barchart = new Chart(ctx2, {
      type: 'bar',
      data:{
          labels: x_dates,
          datasets:[{
            label: "in millions",
            data: y_revenue,
            backgroundColor: 'blue',
            borderWidth:1,
            borderColor:'black',
            hoverBorderWidth:2,
            hoverBorderColor:'black'
        }]
      },
      options: {
        title:{
            display:true,
            text:'Sales',
            fontSize:25
          },
        legend:{
          display:false,
          position:'right',
          labels:{
              fontColor:'orange'
          },
          onClick: (e) => e.stopPropagation()
        },
        layout:{
          padding:{
            left:20,
            right:20,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });

    // Chart 3:  Updates 
    document.getElementById("chartContainer3").innerHTML = '&nbsp;';
    document.getElementById("chartContainer3").innerHTML = '<canvas id="lineChart" >lineChart</canvas>';
    var ctx3 = document.getElementById('lineChart').getContext('2d');
    const linechart = new Chart(ctx3, {
      type: 'line',
      data: {
        labels: x_dates,
        datasets:[ {
          label:"Updates",
          data:y_updates,
          fill : false,
          backgroundColor: 'blue',
          borderWidth:2,
          borderColor:'black',
          hoverBorderWidth:3,
          hoverBorderColor:'black'
        }]
      },
      options: {
        title:{
            display:true,
            text:'Updates',
            fontSize:25
        },
        legend:{
          display:false,
          position:'right',
          labels:{
              fontColor:'orange'
          },
          onClick: (e) => e.stopPropagation()
        },
        layout:{
          padding:{
            left:20,
            right:20,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });
  }
};

