var firebaseConfig = {
    apiKey: "AIzaSyD1AomaI1AMZmvOgd0z_8_w2g289ITRiX8",
    authDomain: "userauth-capstone.firebaseapp.com",
    databaseURL: "https://userauth-capstone.firebaseio.com",
    projectId: "userauth-capstone",
    storageBucket: "userauth-capstone.appspot.com",
    messagingSenderId: "546593699900",
    appId: "1:546593699900:web:c63e395d5c5af69fc3ab39",
    measurementId: "G-N9WZVE2YST"
  };
  
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

